

public class Dessert extends Food{
	
	public Dessert(String location, int floor, int amount){
		super(location, floor, amount);
	}
	public void taken(int takenAmount) {
		amount -= takenAmount;
	}
	
}
