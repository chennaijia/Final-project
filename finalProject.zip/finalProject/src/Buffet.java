

public class Buffet{
	private String location;
	private int floor;
	public Buffet(String location, int floor){
		this.location = location;
		this.floor = floor;
	}
	
	public String getInfo() {
		return "There are buffet at " + location + " at " + floor +" floor";
	}
	
	public String getLocation() {
		return location + " " + floor +"F";
	}
}
