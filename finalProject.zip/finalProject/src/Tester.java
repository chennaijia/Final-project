import java.util.Scanner;
import java.util.ArrayList;

public class Tester {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String location;
		int floor;
		int amount;
		String type;
		int number;
		
		ArrayList<Bento> bentoes= new ArrayList<Bento>();
		ArrayList<Dessert> desserts= new ArrayList<Dessert>();
		ArrayList<Buffet> buffets= new ArrayList<Buffet>();
		
		System.out.println("多少筆資料");
		number = sc.nextInt();
		
		for(int i = 0;i < 40;i++) {
			System.out.print("-");
		}
		System.out.print("\n");
		
		System.out.println("please enter in order of the foods' location, floor, amount and type");
		
		for(int i = 0;i < number;i++) {
			location = sc.next();
			floor = sc.nextInt();
			amount = sc.nextInt();
			type = sc.next();
			if(type.equals("bento")) {
				Bento bento = new Bento (location, floor, amount);
				bentoes.add(bento);
			}else if(type.equals("dessert")) {
				Dessert dessert = new Dessert (location, floor, amount);
				desserts.add(dessert);
			}else if(type.equals("buffet")){
				Buffet buffet = new Buffet (location, floor);
				buffets.add(buffet);
			}
		}
		
		for(int i = 0;i < 40;i++) {
			System.out.print("-");
		}
		System.out.print("\n");
		
		System.out.println("目前剩餘:\nbento:");
		for (Bento bento: bentoes) {
			bento.getInfo();
		}
		System.out.println("dessert:");
		for (Dessert dessert: desserts) {
			dessert.getInfo();
		}
		System.out.println("buffet:");
		for (Buffet buffet: buffets) {
			System.out.println(buffet.getInfo());
		}
		
		for(int i = 0;i < 40;i++) {
			System.out.print("-");
		}
		System.out.print("\n");
		
		System.out.println("What do you like to eat?");
		type = sc.next();
		if(type.equals("bento")) {
			int i = 1;
			for (Bento bento: bentoes) {
				System.out.println(i + ". " + bento.getLocation());
				i++;
			}
			System.out.println("Which and how many do you like to eat?");
			int choise;
			choise = sc.nextInt();
			amount = sc.nextInt();
			bentoes.get(choise-1).taken(amount);
		}else if(type.equals("dessert")) {
			int i = 1;
			for (Dessert dessert: desserts) {
				System.out.println(i + ". " + dessert.getLocation());
				i++;
			}
			System.out.println("Which and how many do you like to eat?");
			int choise;
			choise = sc.nextInt();
			amount = sc.nextInt();
			bentoes.get(choise-1).taken(amount);
		}else if(type.equals("buffet")) {
			int i = 1;
			for (Buffet buffet: buffets) {
				System.out.println(i + ". "+ buffet.getLocation());
				i++;
			}
			System.out.println("Which and how many do you like to eat?");
			int choise;
			choise = sc.nextInt();
			amount = sc.nextInt();
		}
		
		for(int i = 0;i < 40;i++) {
			System.out.print("-");
		}
		System.out.print("\n");
		
		System.out.println("目前剩餘:\nbento:");
		for (Bento bento: bentoes) {
			bento.getInfo();
		}
		System.out.println("dessert:");
		for (Dessert dessert: desserts) {
			dessert.getInfo();
		}
		System.out.println("buffet:");
		for (Buffet buffet: buffets) {
			System.out.println(buffet.getInfo());
		}
	}

}
