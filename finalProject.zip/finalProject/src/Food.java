

public class Food {
	protected String location;
	protected int floor;
	protected int amount;
	protected String type;
	
	public Food(String location, int floor, int amount) {
		this.location = location;
		this.floor = floor;
		this.amount = amount;
	}
	
	public void getInfo() {
		System.out.println("There are " + amount + " left at " + location + " at " + floor +" floor");
	}
	
	public String getLocation() {
		return location + " " + floor +"F, " + amount + " left";
	}
}
